package net.tickmc.megizen.bukkit.properties;

import com.denizenscript.denizen.objects.EntityTag;
import com.ticxo.modelengine.api.ModelEngineAPI;
import com.ticxo.modelengine.api.model.bone.behavior.BoneBehavior;
import net.tickmc.megizen.bukkit.objects.MegBoneTag;
import net.tickmc.megizen.bukkit.objects.MegModeledEntityTag;

public class MegizenEntityTagExtensions {

    public static MegModeledEntityTag getModeledEntity(EntityTag entity) {
        return new MegModeledEntityTag(entity.getBukkitEntity());
    }


    public static void register() {

        EntityTag.tagProcessor.registerTag(MegModeledEntityTag.class, "modeled_entity", (attribute, entity) -> {
            return getModeledEntity(entity);
        });


        EntityTag.tagProcessor.registerTag(MegBoneTag.class, "mounted_bone", (attribute, entity) -> {
            if (ModelEngineAPI.getMountPairManager().getController(entity.getUUID()).getMount() == null) {
                return null;
            }
            return new MegBoneTag(((BoneBehavior) ModelEngineAPI.getMountPairManager().getController(entity.getUUID()).getMount()).getBone());
        });
    }
}
