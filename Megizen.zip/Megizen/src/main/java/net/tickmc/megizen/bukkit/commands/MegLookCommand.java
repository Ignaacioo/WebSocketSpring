package net.tickmc.megizen.bukkit.commands;

import com.denizenscript.denizen.objects.EntityTag;
import com.denizenscript.denizen.objects.LocationTag;
import com.denizenscript.denizencore.objects.ObjectTag;
import com.denizenscript.denizencore.objects.core.ElementTag;
import com.denizenscript.denizencore.scripts.ScriptEntry;
import com.denizenscript.denizencore.scripts.commands.AbstractCommand;
import com.denizenscript.denizencore.scripts.commands.generator.ArgDefaultNull;
import com.denizenscript.denizencore.scripts.commands.generator.ArgLinear;
import com.denizenscript.denizencore.scripts.commands.generator.ArgName;
import com.denizenscript.denizencore.scripts.commands.generator.ArgPrefixed;
import com.denizenscript.denizencore.utilities.debugging.Debug;
import com.ticxo.modelengine.api.model.ActiveModel;
import com.ticxo.modelengine.api.model.ModeledEntity;
import com.ticxo.modelengine.api.nms.entity.wrapper.BodyRotationController;
import com.ticxo.modelengine.api.nms.entity.wrapper.LookController;
import net.tickmc.megizen.bukkit.objects.MegActiveModelTag;
import net.tickmc.megizen.bukkit.objects.MegModeledEntityTag;

public class MegLookCommand extends AbstractCommand {

    public MegLookCommand() {
        setName("meglook");
        setSyntax("meglook [yaw:<new_yaw>] [model:<active_model>]");
        autoCompile();
    }

    // <--[command]
    // @Name MegLook
    // @Syntax meglook [yaw:<new_yaw>] [model:<active_model>]
    // @Required 2
    // @Short Sets a new yaw for the model
    // @Group Megizen
    //
    // @Description
    // Sets a new yaw for the model
    // -->

    public static void autoExecute(ScriptEntry scriptEntry,
                                   @ArgName("yaw") @ArgPrefixed @ArgDefaultNull String yaw,
                                   @ArgName("model") @ArgPrefixed MegActiveModelTag model) {

        ActiveModel activeModel = model.getActiveModel();

        BodyRotationController rotationController = activeModel.getModeledEntity().getBase().getBodyRotationController();
        rotationController.setYBodyRot(Float.parseFloat(yaw));

    }
}