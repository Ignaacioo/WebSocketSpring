Megizen
---------

**Megizen: Adds interop between ModelEngine and Denizen!**

## Download

Dev builds can be found [here](https://ci.heypr.dev/job/Megizen/).

## Usage

The documentation for Megizen can be found [here](https://0tickpulse.github.io/megizen-docs/).

## Credits

This project is based on the [Depenizen](https://github.com/DenizenScript/Depenizen) project, which was released under the MIT license.

Additionally, this project was contributed to by the following people:

[![](https://github.com/heypr.png?size=50)](https://github.com/heypr)
[![](https://github.com/davight.png?size=50)](https://github.com/davight)
[![](https://github.com/0tickpulse.png?size=50)](https://github.com/0tickpulse)
